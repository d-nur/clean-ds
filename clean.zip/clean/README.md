DEMO:
https://www.free-css.com/assets/files/free-css-templates/preview/page212/clean/