<?php
if ( has_post_thumbnail() ) {
	$img_url = get_the_post_thumbnail_url();
} else {
	$img_url = get_template_directory_uri() . '/assets/images/noimage.jpg';
}

?>

<img src="<?php echo $img_url; ?>" alt="">
<br><br><br>
<div class="fh5co-portfolio-description">
    <p><?php the_content(); ?></p>
</div>
