<?php
if ( has_post_thumbnail() ) {
    get_the_post_thumbnail();
}

?>
<br><br><br>
<div class="fh5co-portfolio-description">
    <p><?php the_content(); ?></p>
</div>
