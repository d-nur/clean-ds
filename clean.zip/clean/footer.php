<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Clean
 */

?>

</div>

<footer id="fh5co-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 text-center">
	            <?php echo get_theme_mod('clean_footer_content'); ?>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>
